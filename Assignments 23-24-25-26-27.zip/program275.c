#include <stdio.h>
void charIndexCheck(char ch[], int size)
{
    int iCnt = 0;
    for (iCnt = size; iCnt >= 0; iCnt--)
    {
        printf("%c", ch[iCnt]);
    }
}
int main()
{
    char ch[10];

    printf("Enter String from user:\n");
    scanf("%[^'\n']s", ch);
    charIndexCheck(ch, 10);
    return 0;
}